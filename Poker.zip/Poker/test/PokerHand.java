
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asnopek
 */
class PokerHand {
    
    public ArrayList<Card> hand = new ArrayList();
    
    public PokerHand()
    {
//     Deck d = new Deck();
//        
//        for(int i = 0; i < 6; i ++)
//        {
//            int a = (int)(Math.random()*d.cardDeck.size())+1;
//            hand.add(d.cardDeck.get(a));
//            d.cardDeck.remove(a);
//        }   
    }
    
    public void newHand(){
        
        hand.clear();
        Deck d = new Deck();
        
        for(int i = 0; i < 6; i ++)
        {
            int a = (int)(Math.random()*d.cardDeck.size())+1;
            hand.add(d.cardDeck.get(a));
            d.cardDeck.remove(a);
        }
        
    }
    
    public ArrayList<Card> sortHand(ArrayList<Card> unSortedHand)
    {
        Card maxCard = unSortedHand.get(0);
        int maxIndex = 0;
        ArrayList<Card> sortedHand = new ArrayList();
        
        for(int x =0; x < 5; x++)
        {
        for(int i =0; i < unSortedHand.size()-i; i++)
        {
            if (unSortedHand.get(i).number < unSortedHand.get(i+1).number)
            {
                maxCard = unSortedHand.get(i+1);
                maxIndex = i+1;
            }
  
        }
        
        sortedHand.add(maxCard); 
        unSortedHand.remove(maxIndex);
        }
        return sortedHand;
    }
    
    public String rankHand(){
        if(royalFlush())
        {
            return "Royal Flush";
        }
        
        if(straightFlush())
        {
            return "Straight Flush";
        }
        
        if(fullHouse())
        {
            return "Full House";
        }
        
        if(flush())
        {
            return "Flush";
        }
        
        if(straight())
        {
            return "Straight";
        }
        
        if(threeKind())
        {
            return "Three Kind";
        }
        
        if(twoPair())
        {
            return "Two Pair";
        }
        
        if(onePair())
        {
            return "One Pair";
        }
        else{
            
        }
        int maxValue = hand.get(0).number; 
    
        for(int i=1; i < hand.size(); i++)
            { 
            if(hand.get(i).number > maxValue)
                { 
                //setting the max value to the first card in the hand, and changing it here if it's bigger
                maxValue = hand.get(i).number;
                }
            }
        return maxValue + " High";
    }
    
    public boolean onePair()
    {
       for(int i = 0; i < hand.size(); i ++)
       {
           for(int x = 0; x < hand.size(); x ++)
           {
               if(i != x && hand.get(i).number==hand.get(x).number)
               {
                   return true;
               }
           }
       }
       return false;
    }
    
    public boolean twoPair()
    {
        ArrayList<Card> newHand = new ArrayList();
        
        for(int i = 0; i < hand.size(); i++)
        {
            newHand.add(hand.get(i));
        }
        
        for(int i = 0; i < hand.size(); i ++)
        {
           for(int x = 0; x < hand.size(); x ++)
           {
               if(i != x && hand.get(i).number==hand.get(x).number)
               {
                   newHand.remove(x);
                   newHand.remove(i);
                   x = hand.size();
                   i = hand.size();
               }
           }
       }
       for(int i = 0; i < newHand.size(); i ++)
        {
           for(int x = 0; x < newHand.size(); x ++)
           {
               if(i != x && newHand.get(i).number==newHand.get(x).number)
               {
                   return true;
               }
           }
       } 
       return false;
    }
    
    public boolean threeKind()
    {
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                return true;
                                
                            }
                        }
                    }
            }
        }
        return false;
    }
    

    public boolean straight()
    {
        ArrayList<Card> sortedHand = new ArrayList(hand);
        boolean straightHand = false;
        for (int i = 0; i < sortedHand.size(); i++)
        {
            if ((sortedHand.get(i).number - sortedHand.get(i+1).number) == 1){
               straightHand = true;
            }
            else {
                straightHand = false;
            }
        
        }
        return straightHand;
    }
    
    public boolean flush()
    {
        boolean flushHand = false;
        for (int i = 0; i < hand.size(); i++)
        {
            if(hand.get(i).suit.equals(hand.get(i+1).suit))
            {
                flushHand = true;
            }
            else
            {
                flushHand = false;
            }
        }
        return flushHand;
    }
    
    public boolean fullHouse()
    {
        boolean fullHouseHand = false;
        ArrayList<Card> sortedHand = hand;
        
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                sortedHand.remove(y);
                                sortedHand.remove(x);
                                sortedHand.remove(i);
                                if (sortedHand.get(0).number == sortedHand.get(1).number)
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                        }       
                        
                    }
            }
        }
        return false;
    }
    
    public boolean fourKind()
    {
        boolean fourKindHand = false;
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                for(int bananas = 0; bananas <hand.size(); bananas++)
                                {
                                    if (bananas != y && bananas != x && bananas != i && hand.get(i).number == hand.get(bananas).number)
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                    
                                }
                                
                            }
                        }
                    }
            }
        }
        return false;
    }
    
    
    public boolean straightFlush()
    {
        return flush() && straight();
        
    }
    
    public boolean royalFlush()
    {
        return flush() && straight() && (sortHand(hand).get(0).number==14);
    }
        
       
}

