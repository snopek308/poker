/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author asnopek
 */
public class PokerHandTest {
    
    private PokerHand h;
    
    @Before
    public void setUp(){
       h = new PokerHand();
    }

    @Test
    public void Card(){
        Card c = new Card();
    }
    
    @Test
    public void rankHand(){
        h.hand.add(new Card(14, "Bananas"));
        String result = h.rankHand();
        assertEquals("Correct", "14 High",result);
    }
    
    @Test
    public void Deck(){
        Deck d = new Deck();
    }
    
    @Test
    public void Hand()
    {
        h.newHand();
    }
    
    @Test
    public void onePair()
    {
        h.hand.add(new Card(2, "Bananas"));
        h.hand.add(new Card(2, "Apples"));
        String result = h.rankHand();
        assertEquals("Correct", "One Pair",result);
    }
    
    @Test
    public void twoPair()
    {
        h.hand.add(new Card(5, "Bananas"));
        h.hand.add(new Card(5, "Apples"));
        h.hand.add(new Card(2, "Bananas"));
        h.hand.add(new Card(2, "Apples"));
        String result = h.rankHand();
        assertEquals("Correct", "Two Pair",result);
    }
    
    @Test
    public void threeKind()
    {
        h.hand.add(new Card(6, "Bananas"));
        h.hand.add(new Card(6, "Apples"));
        h.hand.add(new Card(6, "Oreos"));
        String result = h.rankHand();
        assertEquals("Correct", "Three Kind",result);
    }
    
    
    
}
