import java.util.ArrayList;
import java.util.Comparator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asnopek
 */
class PokerHand {
    
    public ArrayList<Card> hand = new ArrayList();
    
    public PokerHand()
    {
//     Deck d = new Deck();
//        
//        for(int i = 0; i < 6; i ++)
//        {
//            int a = (int)(Math.random()*d.cardDeck.size())+1;
//            hand.add(d.cardDeck.get(a));
//            d.cardDeck.remove(a);
//        }   
    }
    
    public void newHand(){
        
        hand.clear();
        Deck d = new Deck();
        
        for(int i = 0; i < 6; i ++)
        {
            int a = (int)(Math.random()*d.cardDeck.size()-1)+1;
            hand.add(d.cardDeck.get(a));
            d.cardDeck.remove(a);
        }
        
    }
    
    public void sortHand()
    {
       hand.sort((Card c1, Card c2) -> c2.number - c1.number);
        
//        unSortedHand.sort(
//                new Comparator<Card> ()
//                {
//                   public int compare(Card c1, Card c2)  {
//                       return c1.number - c2.number;
//                   }
//                });
       
        
       
    }
    
    public String rankHand(){
        if(royalFlush())
        {
            return "Royal Flush";
        }
        
        if(straightFlush())
        {
            return "Straight Flush";
        }
        
        if(fourKind())
        {
            return "Four of a Kind";
        }
        
        if(fullHouse())
        {
            return "Full House";
        }
        
        if(flush())
        {
            return "Flush";
        }
        
        if(straight())
        {
            return "Straight";
        }
        
        if(threeKind())
        {
            return "Three Kind";
        }
        
        if(twoPair())
        {
            return "Two Pair";
        }
        
        if(onePair())
        {
            return "One Pair";
        }
        else{
            
        }
        int maxValue = hand.get(0).number; 
    
        for(int i=1; i < hand.size(); i++)
            { 
            if(hand.get(i).number > maxValue)
                { 
                //setting the max value to the first card in the hand, and changing it here if it's bigger
                maxValue = hand.get(i).number;
                }
            }
        return maxValue + " High";
    }
    
    public boolean onePair()
    {
       for(int i = 0; i < hand.size(); i ++)
       {
           for(int x = 0; x < hand.size(); x ++)
           {
               if(i != x && hand.get(i).number==hand.get(x).number)
               {
                   return true;
               }
           }
       }
       return false;
    }
    
    public boolean twoPair()
    {
        ArrayList<Card> newHand = new ArrayList();
        
        for(int i = 0; i < hand.size(); i++)
        {
            newHand.add(hand.get(i));
        }
        
        for(int i = 0; i < hand.size(); i ++)
        {
           for(int x = 0; x < hand.size(); x ++)
           {
               if(i != x && hand.get(i).number==hand.get(x).number)
               {
                   newHand.remove(x);
                   newHand.remove(i);
                   x = hand.size();
                   i = hand.size();
               }
           }
       }
       for(int i = 0; i < newHand.size(); i ++)
        {
           for(int x = 0; x < newHand.size(); x ++)
           {
               if(i != x && newHand.get(i).number==newHand.get(x).number)
               {
                   return true;
               }
           }
       } 
       return false;
    }
    
    public boolean threeKind()
    {
        
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                return true;
                                
                            }
                        }
                    }
            }
        }
        return false;
    }
    

    public boolean straight()
    {
        sortHand();
        boolean straightHand = false;
        for (int i = 0; i < hand.size()-1; i++)
        {
            if ((hand.get(i).number - hand.get(i+1).number) == 1){
               straightHand = true;
            }
            else {
                straightHand = false;
            }
        
        }
        return straightHand;
    }
    
    public boolean flush()
    {
        boolean flushHand = false;
        for (int i = 0; i < hand.size()-1; i++)
        {
            if(hand.get(i).suit.equals(hand.get(i+1).suit))
            {
                flushHand = true;
            }
            else
            {
                flushHand = false;
            }
        }
        return flushHand;
    }
    
    public boolean fullHouse()
    {
        ArrayList<Card> sortedHand = new ArrayList();
        for(Card c: hand)
        {
            sortedHand.add(c);
        }
        
        
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                sortedHand.remove(y);
                                sortedHand.remove(x);
                                sortedHand.remove(i);
                                if (sortedHand.get(0).number == sortedHand.get(1).number)
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                        }       
                        
                    }
            }
        }
        return false;
    }
    
    public boolean fourKind()
    {
        ArrayList<Card> sortedHand = new ArrayList();
        for(Card c: hand)
        {
            sortedHand.add(c);
        }
        
        for(int i = 0; i < hand.size(); i++)
        {
            for(int x = 0; x < hand.size(); x++)
            {
                    if(i != x && hand.get(i).number==hand.get(x).number)
                    {
                        for(int y = 0; y < hand.size(); y++)
                        {
                            if(y != i && y != x && hand.get(i).number==hand.get(y).number)
                            {
                                
                                sortedHand.remove(y);
                                sortedHand.remove(x);
                                sortedHand.remove(i);
                                if (sortedHand.get(0).number == hand.get(y).number || sortedHand.get(1).number == hand.get(y).number)
                                {
                                    return true;
                                }
                                else 
                                {
                                    return false;
                                }
                            }
                        }
                    }
            }
        }
        return false;
    }
    
    
    public boolean straightFlush()
    {
        return flush() && straight();
        
    }
    
    public boolean royalFlush()
    {
        sortHand();
        return flush() && straight() && (hand.get(0).number==14);
    }
        
       
}
