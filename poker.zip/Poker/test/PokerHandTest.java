/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author asnopek
 */
public class PokerHandTest {
    
    private PokerHand h;
    
    @Before
    public void setUp(){
       h = new PokerHand();
    }

    @Test
    public void Card(){
        Card c = new Card();
    }
    
    @Test
    public void rankHand(){
        h.hand.add(new Card(14, "Bananas"));
        String result = h.rankHand();
        assertEquals("Correct", "14 High",result);
    }
    
    @Test
    public void Deck(){
        Deck d = new Deck();
    }
    
    @Test
    public void Hand()
    {
        h.newHand();
    }
    
    @Test
    public void onePair()
    {
        h.hand.add(new Card(2, "Bananas"));
        h.hand.add(new Card(2, "Apples"));
        h.hand.add(new Card(4, "Yo-Yo"));
        h.hand.add(new Card(5, "Yes"));
        h.hand.add(new Card(7, "No"));
        String result = h.rankHand();
        assertEquals("Correct", "One Pair",result);
    }
    
    @Test
    public void twoPair()
    {
        h.hand.add(new Card(5, "Bananas"));
        h.hand.add(new Card(5, "Apples"));
        h.hand.add(new Card(2, "Bananas"));
        h.hand.add(new Card(2, "Apples"));
        h.hand.add(new Card(4, "Yo-Yo"));
        String result = h.rankHand();
        assertEquals("Correct", "Two Pair",result);
    }
    
    @Test
    public void threeKind()
    {
        h.hand.add(new Card(6, "Bananas"));
        h.hand.add(new Card(6, "Apples"));
        h.hand.add(new Card(6, "Oreos"));
        h.hand.add(new Card(4, "Yo-Yo"));
        h.hand.add(new Card(2, "Skateboard"));
        String result = h.rankHand();
        assertEquals("Correct", "Three Kind",result);
    }
    
    @Test
    public void fourKind()
    {
        h.hand.add(new Card(6, "Bananas"));
        h.hand.add(new Card(6, "Apples"));
        h.hand.add(new Card(6, "Oreos"));
        h.hand.add(new Card(6, "Cookie"));
        h.hand.add(new Card(4, "Yo-Yo"));
        String result = h.rankHand();
        assertEquals("Correct", "Four of a Kind",result);
    }
    
    @Test
    public void fullHouse()
    {
        h.hand.add(new Card(6, "Bananas"));
        h.hand.add(new Card(6, "Apples"));
        h.hand.add(new Card(6, "Oreos"));
        h.hand.add(new Card(4, "Cookie"));
        h.hand.add(new Card(4, "Yo-Yo"));
        String result = h.rankHand();
        assertEquals("Correct", "Full House",result);
    }
    
    @Test
    public void flush()
    {
       h.hand.add(new Card(6, "Bananas"));
       h.hand.add(new Card(7, "Bananas"));
       h.hand.add(new Card(8, "Bananas"));
       h.hand.add(new Card(2, "Bananas"));
       h.hand.add(new Card(10, "Bananas"));
        String result = h.rankHand();
        assertEquals("Correct", "Flush",result); 
    }
    
    @Test
    public void straight()
    {
       h.hand.add(new Card(6, "Bananas"));
       h.hand.add(new Card(7, "Apples"));
       h.hand.add(new Card(8, "Tacos"));
       h.hand.add(new Card(9, "Cake"));
       h.hand.add(new Card(10, "Cereal"));
        String result = h.rankHand();
        assertEquals("Correct", "Straight",result);    
    }
    
    @Test
    public void straightFlush()
    {
      h.hand.add(new Card(6, "Bananas"));
      h.hand.add(new Card(7, "Bananas"));
      h.hand.add(new Card(8, "Bananas"));
      h.hand.add(new Card(9, "Bananas"));
      h.hand.add(new Card(10, "Bananas"));
        String result = h.rankHand();
        assertEquals("Correct", "Straight Flush",result);   
    }
    
    @Test
    public void royalFlush()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
        String result = h.rankHand();
        assertEquals("Correct", "Royal Flush",result); 
    }
    
    @Test
    public void sortHand()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
        h.sortHand();
        int result = h.hand.get(0).number;
        assertEquals("Correct", 14, result); 
    }
    
    @Test
    public void sortHand1()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
        h.sortHand();
        int result = h.hand.get(1).number;
        assertEquals("Correct", 13, result); 
    }
    
    @Test
    public void sortHand2()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
      h.sortHand();
        int result = h.hand.get(2).number;
        assertEquals("Correct", 12, result); 
    }
    
    @Test
    public void sortHand3()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
        h.sortHand();
        int result = h.hand.get(3).number;
        assertEquals("Correct", 11, result); 
    }
    
    @Test
    public void sortHand4()
    {
      h.hand.add(new Card(10, "Bananas"));
      h.hand.add(new Card(11, "Bananas"));
      h.hand.add(new Card(12, "Bananas"));
      h.hand.add(new Card(13, "Bananas"));
      h.hand.add(new Card(14, "Bananas"));
        h.sortHand();
        int result = h.hand.get(4).number;
        assertEquals("Correct", 10, result); 
    }
    
    
}
