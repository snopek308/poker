
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asnopek
 */
class Deck {
    
    public ArrayList<Card> cardDeck = new ArrayList();
    
    public Deck()
    {
        for(int i =0; i < 4; i++)
        {
            for(int x = 2; x < 15; x ++)
            {
                String suit = "";
                switch(i)
                {
                    case 0:
                    {
                        suit = "Hearts";
                        break;
                    }
                    case 1:
                    {
                        suit = "Diamonds";
                        break;
                    }
                    case 2:
                    {
                        suit = "Clubs";
                        break;
                    }
                    case 3:
                    {
                        suit = "Spades";
                        break;
                    }

                }
                cardDeck.add(new Card(x, suit));
            }
        }
    }
    
}
